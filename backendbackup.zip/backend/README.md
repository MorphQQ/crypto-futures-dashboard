Crypto Futures Dashboard (Modified v0.3.3 Fork)

Real-time monitoring for crypto futures OI, L/S ratios, and deltas.