from __future__ import annotations

import futuresboard.app


app = futuresboard.app.init_app()
