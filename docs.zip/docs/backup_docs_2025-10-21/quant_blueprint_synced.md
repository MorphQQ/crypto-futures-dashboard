# Quant Blueprint (Synced)

## Auto-KPI Update (2025-10-21 23:54)
| Metric | Value |
|---------|-------|
| **Weighted OI (USD)** | \$5.19B |
| **Phase** | P3.6 - UTF8 Logging + QuantSummary Stable |
| **Uptime** | 40.0% |
| **Status** | Weighted OI from 50 pairs |
