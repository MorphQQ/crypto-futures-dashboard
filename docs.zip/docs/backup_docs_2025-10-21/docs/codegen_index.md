# Code Export Index - Crypto Futures Dashboard (v1.0)

_Last updated: 2025-10-21 23:46:48_

| File | Type | Lines | Size (KB) | Path |
|------|------|-------:|---------:|------|
| docs\codegen_index.md | .md | 10 | 0.4 | docs\codegen_index.md |
| docs\project_data.json | .json | 35 | 1.5 | docs\project_data.json |

_Total Files: 2 | Phase: Unknown | Uptime: N/A_